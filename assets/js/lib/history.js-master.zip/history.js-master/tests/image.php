<?php
header('Content-type: image/jpeg');
sleep(10);
